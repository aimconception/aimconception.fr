# Mapping photos → noms de fichiers attendus
## Dossier : img/realisations/

| Votre fichier original | Nom à utiliser | Page concernée |
|---|---|---|
| Projet_maison_Lorient.png | lorient-maison-r2.jpg | lorient.html, index.html |
| Projet_d_extension_de_Lorient.png | lorient-extension-piscine.jpg | (galerie) |
| Projet_maison_Inzinzach_Lochrist.png | inzinzac-villa-nuit.jpg | inzinzac-lochrist.html, index.html |
| Projet_maison_Inzinzach_Lanester.png | lanester-plain-pied.jpg | (galerie) |
| Projet_de_cuisine_d_été_Lanester.png | lanester-cuisine-ete.jpg | lanester.html, index.html |
| Maison_de_vacances_Hennebont.png | hennebont-maison-vacances.jpg | hennebont.html |
| proiect_casa_de_vacanta_Guidel.png | guidel-maison-vacances.jpg | guidel.html |
| proiect_casa_si_amenajare_exterioara_Caudan_.png | caudan-maison-pierre-paysager.jpg | caudan.html |
| Projet_de_rénovation_à_Bubry.png | bubry-renovation-pierre.jpg | bubry.html, index.html (hero) |
| Projet_2_maisons_passives_Ploemeur.png | ploemeur-maisons-passives.jpg | ploemeur.html, index.html |
| Projet_d_extension_de_Ploemeur.png | ploemeur-extension-piscine.jpg | (galerie) |
| Projet_d_extension_de_Ploemeur__2_.png | ploemeur-extension-facade.jpg | (galerie) |
| Avant_Projet.png | avant-projet-facades.jpg | (services / blog) |
| Plan_d_aménagement_intérieur.png | plan-amenagement-interieur.jpg | (services) |
| Projet_3D_d_intérieur.png | projet-3d-interieur.jpg | (services) |
| Plan_détaillé_VS.png | plan-vide-sanitaire.jpg | (services technique) |
| Plans_Coupe.png | plans-coupe-technique.jpg | (services technique) |

## Instructions
1. Renommez chaque fichier selon la colonne "Nom à utiliser"
2. Vous pouvez garder le format .png — modifiez alors les src dans les HTML (.jpg → .png)
3. Placez tous les fichiers dans : img/realisations/
4. Le héros de la page d'accueil utilise bubry-renovation-pierre.jpg

## Structure complète du site
```
aimconception-v2/
├── index.html
├── style.css
├── services.html          (à créer)
├── realisations.html      (à créer)
├── contact.html           (à créer)
├── mentions-legales.html  (à créer)
├── img/
│   └── realisations/      ← vos photos ici
└── localites/
    ├── releve-existant.html
    ├── lorient.html
    ├── lanester.html
    ├── ploemeur.html
    ├── guidel.html
    ├── hennebont.html
    ├── caudan.html
    ├── inzinzac-lochrist.html
    ├── bubry.html
    ├── quimperle.html
    ├── moelan-sur-mer.html
    ├── clohars-carnoet.html
    ├── riec-sur-belon.html
    └── bannalec.html
```
